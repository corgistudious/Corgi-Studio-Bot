const MarketAsset=require('../models/MarketAsset');const MarketPortfolio=require('../models/MarketPortfolio');const MarketEvents=require('./marketEventService');const UserEconomy=require('../models/UserEconomy');const {walletFilter,ensureWallet}=require('./economyWallet');
const SEEDS=[['CRGI','Corgi Industries',1284,.025],['NOVA','Nova Systems',742,.04],['BYTE','Byte Labs',2410,.035],['ORBT','Orbit Works',386,.05],['LUNA','Luna Energy',925,.045],['NEXUS','Nexus Group',1630,.03]];
async function seed(){for(const [symbol,name,price,volatility] of SEEDS)await MarketAsset.updateOne({symbol},{$setOnInsert:{symbol,name,price,previousPrice:price,open:price,high:price,low:price,volatility,lastTickAt:new Date()}},{upsert:true});}
async function tick(){
  await seed();
  const {created,events,ended}=await MarketEvents.cycle();
  const assets=await MarketAsset.find({enabled:true});

  for(const a of assets){
    const old=a.price;
    const natural=(Math.random()+Math.random()-1)*a.volatility;
    const eventPressure=MarketEvents.modifierFor(a.symbol,events);
    const totalShock=Math.max(-0.08,Math.min(0.08,natural+eventPressure));
    const next=Math.max(10,Number((old*(1+totalShock)).toFixed(2)));

    a.previousPrice=old;
    a.price=next;
    a.high=Math.max(a.high,next);
    a.low=Math.min(a.low,next);
    a.volume+=Math.floor(100+Math.random()*5000);
    a.lastTickAt=new Date();
    await a.save();
  }

  assets.marketEventCreated=created||null;
  assets.marketEvents=events||[];
  assets.marketEventsEnded=ended||[];
  return assets;
}
async function list(){await seed();return MarketAsset.find({enabled:true}).sort({symbol:1}).lean();}
async function portfolio(userId){const [p,w,assets]=await Promise.all([MarketPortfolio.findOneAndUpdate({userId:String(userId)},{$setOnInsert:{userId:String(userId)}},{upsert:true,returnDocument:'after'}),ensureWallet(userId),list()]);const prices=new Map(assets.map(a=>[a.symbol,a.price]));let invested=0,value=0;for(const x of p.positions){invested+=x.avgCost*x.quantity;value+=(prices.get(x.symbol)||0)*x.quantity;}return{p,w,assets,invested,value,unrealized:value-invested,total:Number(w.cstar||0)+value};}
async function buy(userId,symbol,quantity){quantity=Math.floor(Number(quantity));if(!Number.isInteger(quantity)||quantity<1)throw new Error('INVALID_QUANTITY');const a=await MarketAsset.findOne({symbol:String(symbol).toUpperCase(),enabled:true});if(!a)throw new Error('UNKNOWN_SYMBOL');const cost=Math.ceil(a.price*quantity);await ensureWallet(userId);const w=await UserEconomy.findOneAndUpdate({...walletFilter(userId),cstar:{$gte:cost}},{$inc:{cstar:-cost}},{returnDocument:'after'});if(!w)throw new Error('INSUFFICIENT_CSTAR');const p=await MarketPortfolio.findOneAndUpdate({userId:String(userId)},{$setOnInsert:{userId:String(userId)}},{upsert:true,returnDocument:'after'});let pos=p.positions.find(x=>x.symbol===a.symbol);if(pos){const total=pos.avgCost*pos.quantity+cost;pos.quantity+=quantity;pos.avgCost=total/pos.quantity;}else p.positions.push({symbol:a.symbol,quantity,avgCost:a.price});p.trades++;await p.save();return{asset:a,quantity,cost,balance:w.cstar};}
async function sell(userId,symbol,quantity){quantity=Math.floor(Number(quantity));if(!Number.isInteger(quantity)||quantity<1)throw new Error('INVALID_QUANTITY');const a=await MarketAsset.findOne({symbol:String(symbol).toUpperCase(),enabled:true});if(!a)throw new Error('UNKNOWN_SYMBOL');const p=await MarketPortfolio.findOne({userId:String(userId)});const pos=p?.positions.find(x=>x.symbol===a.symbol);if(!pos||pos.quantity<quantity)throw new Error('NOT_ENOUGH_SHARES');const proceeds=Math.floor(a.price*quantity),basis=pos.avgCost*quantity;pos.quantity-=quantity;p.realizedPnl+=(proceeds-basis);p.trades++;p.positions=p.positions.filter(x=>x.quantity>0);await p.save();const w=await UserEconomy.findOneAndUpdate(walletFilter(userId),{$inc:{cstar:proceeds}},{returnDocument:'after',upsert:true});return{asset:a,quantity,proceeds,balance:w.cstar};}
module.exports={seed,tick,list,portfolio,buy,sell};

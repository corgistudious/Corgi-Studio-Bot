const {Schema,model}=require('mongoose');
const schema=new Schema({campaignId:{type:Schema.Types.ObjectId,ref:'AdCampaign',required:true,index:true},day:{type:String,required:true},impressions:{type:Number,default:0,min:0},clicks:{type:Number,default:0,min:0}},{timestamps:true});
schema.index({campaignId:1,day:1},{unique:true});
module.exports=model('AdMetric',schema);
